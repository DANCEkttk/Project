package jp.co.sss.sys.form;

/**
 * フォームクラス
 * @author Inoue Nami
 *
 */
public class MypageForm {

	  
	  /**
		 * 社員番号
		 */
		private String empId;
		
		/**
		 * 名前
		 */
		private String empName;
		
		/**
		 * パスワード
		 */
		private String password;
		
		/**
		 * 生年月日
		 */
		private String birthday;
		
		/**
		 * 性別
		 */
		private String gender;
		
		

		//ゲッターセッター
		public String getEmpId() {
			return empId;
		}

		public void setEmpId(String empId) {
			this.empId = empId;
		}
		
		public String getEmpName() {
			return empName;
		}

		public void setEmpName(String empName) {
			this.empName = empName;
		}

		public String getPassword() {
			return password;
		}

		public void setPassword(String password) {
			this.password = password;
		}
		
		public String getBirthday() {
			return birthday;
		}

		public void setBirthday(String birthday) {
			this.birthday = birthday;
		}
		
		
		public String getGender() {
			return gender;
		}

		public void setGender(String gender) {
			this.gender = gender;
		}	

}
