package jp.co.sss.sys.controller;


import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.SessionAttributes;
import org.springframework.web.bind.support.SessionStatus;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import jp.co.sss.sys.entity.Employee;
import jp.co.sss.sys.form.LoginForm;
import jp.co.sss.sys.form.MypageForm;
import jp.co.sss.sys.form.RegisterForm;
import jp.co.sss.sys.repository.EmployeeRepository;

/**
 * コントローラークラス
 * @author Kamata Takuya
 * @version 1.0.0
 *
 */
@SessionAttributes(value = { "loginUser" }) // (1)
@Controller
@Validated
public class IndexController {

	@Autowired
	EmployeeRepository empRepository;
	

	
	
	/**
	 * プレースホルダー
	 */
	@Autowired
	  private NamedParameterJdbcTemplate jdbcTemplate;
	
	
	
	/**
	 * ログイン画面を表示する
	 * @param loginForm
	 * @param model
	 * @return login.html
	 */
	@RequestMapping(path = "/login", method = RequestMethod.GET)
	public String login(@ModelAttribute("error") String error, Model model,SessionStatus sessionStatus) {
			

			model.addAttribute("error",error);
			//**Modelに"loginForm"が存在しない時だけ、下記の処理を実行*/
			if (!model.containsAttribute("loginForm")) {
				model.addAttribute("loginForm", new LoginForm());
			}
	      
	      //**セッションを破棄
	      sessionStatus.setComplete();
	      
		
		return "login";
	}

	/**
	 * 入力された値を元にログイン認証し、トップ画面に遷移する
	 * @param loginForm
	 * @param model
	 * @return top.html
	 * @return login.html
	 */
	@RequestMapping(path = "/top", method = RequestMethod.POST)
	public String tologin(Model model, @Validated @ModelAttribute("loginForm") LoginForm loginForm, BindingResult result, RedirectAttributes redirectAttributes) {
		if(result.hasErrors()) {
			System.out.print(result);
			redirectAttributes.addFlashAttribute("org.springframework.validation.BindingResult.loginForm", result);
			redirectAttributes.addFlashAttribute("loginForm", loginForm);
			return "redirect:login";
			
		} else {
			
			String empId = loginForm.getEmpId();
			String password = loginForm.getPassword();
			Employee user = findByIdAndPass(empId, password);
			
		    if(user == null) {
		        //**user内に値が存在しない場合
		        String error = "社員番号またはパスワードが違います。";
		        model.addAttribute("error",error);
				redirectAttributes.addFlashAttribute("error", error);
		        
		        return "redirect:login";
		    }
			/**DBに登録されているすべての社員情報を取得
			* @return 社員情報一覧
			*/
		    List<Employee> employeelist = this.empRepository.findAll();
		    
		    model.addAttribute("loginUser", user);
		    model.addAttribute("employeelist", employeelist);

		return "top";
		}
	}


	
	/**
	 * top画面を表示する
	 * @param topForm
	 * @param model
	 * @return top.html
	 */
	@RequestMapping(path = "/top", method = RequestMethod.GET)
	public String top(Model model,SessionStatus sessionStatus) {

		/**
		 * セッション有無を確認
		 * 無ければlogin画面へ
		 * @return login.html
		 */
		if (!model.containsAttribute("loginUser")) {
			return "redirect:login";
		}
		
		/**DBに登録されているすべての社員情報を取得
		* @return 社員情報一覧
		*/
	    List<Employee> employeelist = this.empRepository.findAll();
	    model.addAttribute("employeelist", employeelist);
		return "top";
	}
	
	
	
	/**
	 * マイページ確認・変更画面を表示する
	 * @param MypageForm
	 * @param model
	 * @return mypage.html
	 */
	@RequestMapping(path = "/mypage", method = RequestMethod.GET)
	public String mypage(Model model) {
		 /**
		  * セッション有無を確認
		  * 無ければlogin画面へ
		  * @return login.html
		  */
		  if (!model.containsAttribute("loginUser")) {
			return "redirect:login";
		  }
		
	      //**Modelに"mypageForm"が存在しない時だけ、下記の処理を実行*/
	      if (!model.containsAttribute("mypageForm")) {
	        model.addAttribute("mypageForm", new MypageForm());
	      }
		return "mypage";
	}
	
	/**
	 * マイページ変更完了画面を表示する
	 * @param mypageForm
	 * @param model
	 * @return mypage.html
	 * @return completion.html
	 */
	@RequestMapping(path = "/completion", method = RequestMethod.POST)
	public String completion(Model model
			, @RequestParam("*{empId}")String mypageId
			, @RequestParam("*{empName}")String mypageName
			, @RequestParam("*{password}")String mypagePass
			, @RequestParam("*{birthday}")String mypageBirth
			, @RequestParam("*{gender}")Integer mypageGen
			, MypageForm mypageForm, BindingResult result, RedirectAttributes redirectAttributes) {
		
		
		List<String> message = new ArrayList<String>();
		
		int Namelen = String.valueOf(mypageName).length();
		int Passlen = String.valueOf(mypagePass).length();
		

		/**バリデーションチェック
		* @return エラーメッセージ
		*/
		if (Namelen <= 0) {
			String Nameerror = "名前は入力必須項目です。";
			message.add(Nameerror);
				
			} else if(Namelen >= 17) {
				String Nameerror = "名前は16文字以内で入力してください。";
				message.add(Nameerror);
				}
		
		if (Passlen <= 0) {
			String Passerror = "パスワードは入力必須項目です。";
			message.add(Passerror);
				
			} else if(Passlen >= 17) {
				String Passerror = "パスワードは16文字以内で入力してください。";
				message.add(Passerror);
				}
		if (mypageBirth == null){
			String Birtherror = "生年月日は入力必須項目です。";
			message.add(Birtherror);
		}
		if (mypageBirth == ""){
			String Birtherror = "生年月日は入力必須項目です。";
			message.add(Birtherror);
		}
		
		//**エラーメッセージが出力されているか確認
		if(message.size() >= 1) {
			model.addAttribute("error",message);
			redirectAttributes.addFlashAttribute("error", message);
			return "redirect:mypage";
			
		} else {
			
			String empId = mypageId;
			String empName = mypageName;
			String password = mypagePass;
			Integer Gender = mypageGen;
			
			Date birthday;
			SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd");
			/**生年月日をString型からDate型へ変換
			* @return birthday
			*/
			try {
				birthday = format.parse(mypageBirth);	
				} catch (ParseException e) {
					birthday = null;
				}

			
			Employee user = updateByMydate(empId, empName, password, birthday, Gender);
			
			model.addAttribute("loginUser", user);
					
		return "completion";
		} 
	}
	
	
	
	/**
	 * 社員登録画面を表示する
	 * @param RegisterForm
	 * @param model
	 * @return register.html
	 */
	@RequestMapping(path = "/register", method = RequestMethod.GET)
	public String register(Model model) {
		  /**
		   * セッション有無を確認
		   * 無ければlogin画面へ
		   * @return login.html
		   */
		  if (!model.containsAttribute("loginUser")) {
			return "redirect:login";
		  }
		
	      //**Modelに"registerForm"が存在しない時だけ、下記の処理を実行*/
	      if (!model.containsAttribute("registerForm")) {
	        model.addAttribute("registerForm", new RegisterForm());
	      }
		return "register";
	}
	
	
	
	
	/**
	 * 入力された値を元に社員登録し、社員登録完了画面に遷移する
	 * @param registerForm
	 * @param model
	 * @return regcompletion.html
	 * @return register.html
	 */
	@RequestMapping(path = "/regcompletion", method = RequestMethod.POST)
	public String toregister(@RequestParam("*{gender}")Integer regGen, Model model, @Validated @ModelAttribute("registerForm") RegisterForm registerForm, BindingResult result, RedirectAttributes redirectAttributes) {
		String test = registerForm.getBirthday();
		Integer test2 = regGen;
		System.out.print(test);
		System.out.print(test2);
		
		if(result.hasErrors()) {
			System.out.print(result);
			redirectAttributes.addFlashAttribute("org.springframework.validation.BindingResult.registerForm", result);
			redirectAttributes.addFlashAttribute("registerForm", registerForm);
			return "redirect:register";
			
		} else {
			
			
			String empId = registerForm.getEmpId();
			String empName = registerForm.getEmpName();
			String password = registerForm.getPassword();
			String strbirthday = registerForm.getBirthday();
			Integer gender = regGen;
			
			Date birthday;
			SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd");
			/**生年月日をString型からDate型へ変換
			* @return birthday
			*/
			try {
			birthday = format.parse(strbirthday);	
			} catch (ParseException e) {
				birthday = null;
			}

			Employee reguser = InsertUser(empId, empName, password, birthday, gender);
			

		    model.addAttribute("registerUser", reguser);


		return "regcompletion";
		}
	}
	
	
	
	
	
	
	/**
	 * ログイン画面で入力された値からDB検索を実施
	 * 
	 * @return Employeelist
	 */
	public Employee findByIdAndPass(String empId, String password) {
	    String sql1 = "SELECT emp_id, password, emp_name, birthday, gender FROM employee WHERE emp_id = :empId AND password = :password;";    
	    //プレースホルダーに値を格納する
	    
	    MapSqlParameterSource param1 = new MapSqlParameterSource();
	    param1.addValue("empId", empId);
	    param1.addValue("password", password);
	    
	    List<Employee> EmployeeList = jdbcTemplate.query(sql1, param1,
	        new BeanPropertyRowMapper<Employee>(Employee.class));
	    
	    //userListが空の場合はNull、空でない場合はUserを返す
	    return EmployeeList.isEmpty() ? null : EmployeeList.get(0);
	  }

	
	
	
	/**
	 * マイページ確認・変更画面で入力された値からDB情報を更新
	 * 
	 * @return Employeelist
	 */
	public Employee updateByMydate(String empId, String empName, String password, Date birthday, Integer gender) {
	    
		Employee Mydate = empRepository.findById(empId).orElseThrow();
		
		Mydate.setEmpId(empId);
		Mydate.setEmpName(empName);
		Mydate.setPassword(password);
		Mydate.setBirthday(birthday);
		Mydate.setGender(gender);
		
		empRepository.save(Mydate);
		
		String sql1 = "SELECT emp_id, emp_name, password, birthday, gender FROM employee WHERE emp_id = :empId;";  
		//プレースホルダーに値を格納する
		MapSqlParameterSource param2 = new MapSqlParameterSource();
		param2.addValue("empId", empId);
		
		List<Employee> EmployeeList = jdbcTemplate.query(sql1, param2,
		        new BeanPropertyRowMapper<Employee>(Employee.class));
		    
		    //userListが空の場合はNull、空でない場合はUserを返す
		    return EmployeeList.isEmpty() ? null : EmployeeList.get(0);
	  }
	
	
	
	/**
	 * 社員登録画面で入力された値からDB登録を実施
	 * 
	 * @return Employeelist
	 */
	public Employee InsertUser(String empId, String empName, String password, Date birthday, Integer gender) {
    
		Employee param1 = new Employee();
	    param1.setEmpId(empId);
	    param1.setEmpName(empName);
	    param1.setPassword(password);
	    param1.setBirthday(birthday);
	    param1.setGender(gender);
	    
	    //取得した値からDB登録を実施
	    empRepository.save(param1);

	    List<Employee> employeelist = this.empRepository.findAll();
	    
	    //userListが空の場合はNull、空でない場合はUserを返す
	    return employeelist.isEmpty() ? null : employeelist.get(0);
	  }

	

	    
	}
	
