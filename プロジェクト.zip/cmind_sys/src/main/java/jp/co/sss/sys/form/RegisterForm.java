package jp.co.sss.sys.form;

import javax.validation.constraints.Size;

import org.hibernate.validator.constraints.NotEmpty;


/**
 * フォームクラス
 * @author Inoue Nami
 *
 */
public class RegisterForm {

	  
	  	/**
		 * 社員番号
		 */
		@Size(min=0,max=5,message="社員番号は5文字以内で入力してください。")
		@NotEmpty(message = "社員番号は入力必須項目です。")
		private String empId;
		
		/**
		 * 名前
		 */
		@Size(min=0,max=16,message="名前は16文字以内で入力してください。")
		@NotEmpty(message = "名前は入力必須項目です。")
		private String empName;
		
		/**
		 * パスワード
		 */
		@Size(min=0,max=16,message="パスワードは16文字以内で入力してください。")
		@NotEmpty(message = "パスワードは入力必須項目です。")
		private String password;
		
		/**
		 * 生年月日
		 */
		@NotEmpty(message = "生年月日は入力必須項目です。")
		private String birthday;
		
		/**
		 * 性別
		 */
		private String gender;
		
		

		//ゲッターセッター
		public String getEmpId() {
			return empId;
		}

		public void setEmpId(String empId) {
			this.empId = empId;
		}
		
		public String getEmpName() {
			return empName;
		}

		public void setEmpName(String empName) {
			this.empName = empName;
		}

		public String getPassword() {
			return password;
		}

		public void setPassword(String password) {
			this.password = password;
		}
		
		public String getBirthday() {
			return birthday;
		}

		public void setBirthday(String birthday) {
			this.birthday = birthday;
		}
		
		
		public String getGender() {
			return gender;
		}

		public void setGender(String gender) {
			this.gender = gender;
		}	

}
