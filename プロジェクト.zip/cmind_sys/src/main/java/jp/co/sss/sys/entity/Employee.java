package jp.co.sss.sys.entity;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;


/**
 * エンティティクラス
 * @author Inoue Nami
 *
 */
@Entity
@Table(name = "employee")
public class Employee  {

	/**
	 * 社員番号
	 */
	@Id
	@Column
	private String empId;
	
	/**
	 * 名前
	 */
	@Column
	private String empName;
	
	/**
	 * パスワード
	 */
	@Column
	private String password;
	
	/**
	 * 誕生日
	 */
	@Column
	private Date birthday;
	
	/**
	 * 性別
	 */
	@Column
	private Integer gender;
	

	//ゲッターセッター
	public String getEmpId() {
		return empId;
	}

	public void setEmpId(String empId) {
		this.empId = empId;
	}
	
	public String getEmpName() {
		return empName;
	}

	public void setEmpName(String empName) {
		this.empName = empName;
	}
	
	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}
	
	public Date getBirthday() {
		return birthday;
	}

	public void setBirthday(Date birthday) {
		this.birthday = birthday;
	}
	
	
	public Integer getGender() {
		return gender;
	}

	public void setGender(Integer gender) {
		this.gender = gender;
	}	
	

}
