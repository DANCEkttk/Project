package jp.co.sss.sys.form;

import javax.validation.constraints.Size;

import org.hibernate.validator.constraints.NotEmpty;

/**
 * フォームクラス
 * @author Inoue Nami
 *
 */
public class LoginForm {
	/**
	 * 社員番号
	 */
	@Size(min=0,max=5,message="社員番号は5文字以内で入力してください。")
	@NotEmpty(message = "社員番号は入力必須項目です。")
	private String empId;
	/**
	 * パスワード
	 */
	@Size(min=0,max=16,message="パスワードは16文字以内で入力してください。")
	@NotEmpty(message = "パスワードは入力必須項目です。")
	private String password;

	//ゲッターセッター
	public String getEmpId() {
		return empId;
	}

	public void setEmpId(String empId) {
		this.empId = empId;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

}
